const Chat = require('../models/Chat');
const User = require('../models/User');

exports.sendMessage = async (req, res) => {
  const { content, file, chatId } = req.body;
  try {
    let chat = await Chat.findById(chatId);
    if (!chat) {
      chat = await Chat.create({ users: [req.user._id], messages: [] });
    }
    const message = { sender: req.user._id, content, file };
    chat.messages.push(message);
    await chat.save();
    res.json(chat);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getChats = async (req, res) => {
  try {
    const chats = await Chat.find({ users: req.user._id }).populate('users', 'username email').populate('messages.sender', 'username');
    res.json(chats);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
