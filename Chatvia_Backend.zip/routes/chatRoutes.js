const express = require('express');
const { sendMessage, getChats } = require('../controllers/chatController');
const { protect } = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/message', protect, sendMessage);
router.get('/chats', protect, getChats);

module.exports = router;
